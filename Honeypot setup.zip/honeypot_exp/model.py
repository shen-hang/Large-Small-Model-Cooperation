"""Small OpenAI-compatible client with normalized token accounting."""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from typing import Any, Callable, Mapping, Sequence
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from config import (
    MAX_TOKENS,
    MODEL_PROFILES,
    REQUEST_TIMEOUT_SECONDS,
    STRATEGY_MAX_TOKENS,
    TEMPERATURE,
    TOP_P,
)


Message = Mapping[str, str]
Transport = Callable[[str, Mapping[str, str], Mapping[str, Any], float], Mapping[str, Any]]


class ModelError(RuntimeError):
    """Raised when configuration, transport, or response validation fails."""


@dataclass(frozen=True)
class ChatResult:
    content: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    model: str
    provider: str


def _http_transport(
    url: str,
    headers: Mapping[str, str],
    payload: Mapping[str, Any],
    timeout: float,
) -> Mapping[str, Any]:
    request = Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers=dict(headers),
        method="POST",
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        raise ModelError(f"model API returned HTTP {exc.code}: {detail}") from exc
    except URLError as exc:
        raise ModelError(f"model API request failed: {exc.reason}") from exc
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ModelError("model API returned invalid JSON") from exc


class ModelClient:
    """Provider-neutral client; injectable transport keeps smoke tests offline."""

    def __init__(self, transport: Transport = _http_transport) -> None:
        self._transport = transport

    def chat(
        self,
        messages: Sequence[Message],
        model_name: str,
        *,
        max_tokens: int | None = None,
    ) -> ChatResult:
        profile = MODEL_PROFILES.get(model_name)
        if profile is None:
            known = ", ".join(sorted(MODEL_PROFILES))
            raise ModelError(f"unknown model '{model_name}'; configured models: {known}")
        normalized_messages = self._validate_messages(messages)
        provider = str(profile["provider"])
        base_url = str(profile["base_url"]).rstrip("/")
        key_env = str(profile["api_key_env"])
        api_key = os.getenv(key_env, "")
        if provider != "vllm" and not api_key:
            raise ModelError(f"{key_env} is required for model '{model_name}'")

        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        requested_max_tokens = MAX_TOKENS if max_tokens is None else max_tokens
        if not 1 <= requested_max_tokens <= MAX_TOKENS:
            raise ModelError(f"max_tokens must be between 1 and {MAX_TOKENS}")
        payload = {
            "model": str(profile["api_model"]),
            "messages": normalized_messages,
            "temperature": TEMPERATURE,
            "top_p": TOP_P,
            "max_tokens": requested_max_tokens,
        }
        if "enable_thinking" in profile:
            payload["enable_thinking"] = bool(profile["enable_thinking"])
        if "thinking" in profile:
            payload["thinking"] = dict(profile["thinking"])
        raw = self._transport(
            f"{base_url}/chat/completions",
            headers,
            payload,
            REQUEST_TIMEOUT_SECONDS,
        )
        return self._parse_response(raw, model_name, provider)

    @staticmethod
    def _validate_messages(messages: Sequence[Message]) -> list[dict[str, str]]:
        if not messages:
            raise ModelError("messages must not be empty")
        allowed_roles = {"system", "user", "assistant"}
        normalized: list[dict[str, str]] = []
        for index, message in enumerate(messages):
            role = message.get("role")
            content = message.get("content")
            if role not in allowed_roles or not isinstance(content, str) or not content:
                raise ModelError(f"invalid message at index {index}")
            normalized.append({"role": str(role), "content": content})
        return normalized

    @staticmethod
    def _parse_response(raw: Mapping[str, Any], model_name: str, provider: str) -> ChatResult:
        try:
            content = raw["choices"][0]["message"]["content"]
            usage = raw["usage"]
            prompt_tokens = int(usage["prompt_tokens"])
            completion_tokens = int(usage["completion_tokens"])
            total_tokens = int(usage.get("total_tokens", prompt_tokens + completion_tokens))
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            raise ModelError("model response is missing choices or token usage") from exc
        if not isinstance(content, str):
            raise ModelError("model response content must be text")
        if min(prompt_tokens, completion_tokens, total_tokens) < 0:
            raise ModelError("token counts must be non-negative")
        if total_tokens < prompt_tokens + completion_tokens:
            raise ModelError("total_tokens is smaller than prompt + completion tokens")
        return ChatResult(
            content=content,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            model=model_name,
            provider=provider,
        )


def chat(
    messages: Sequence[Message],
    model_name: str,
    *,
    max_tokens: int | None = None,
) -> ChatResult:
    """Unified public interface required by the execution plan."""

    return ModelClient().chat(messages, model_name, max_tokens=max_tokens)


def smoke_test() -> ChatResult:
    """Validate routing, request parameters, and usage parsing without network I/O."""

    observed: dict[str, Any] = {}

    def fake_transport(
        url: str,
        headers: Mapping[str, str],
        payload: Mapping[str, Any],
        timeout: float,
    ) -> Mapping[str, Any]:
        observed.update(url=url, headers=headers, payload=payload, timeout=timeout)
        return {
            "choices": [{"message": {"role": "assistant", "content": "OpenSSH_8.9p1"}}],
            "usage": {"prompt_tokens": 12, "completion_tokens": 5, "total_tokens": 17},
        }

    old_key = os.environ.get("DASHSCOPE_API_KEY")
    os.environ["DASHSCOPE_API_KEY"] = "offline-smoke-test"
    try:
        result = ModelClient(transport=fake_transport).chat(
            [{"role": "user", "content": "nmap -sV -p 22 10.20.1.10"}],
            "Qwen3-8B",
            max_tokens=STRATEGY_MAX_TOKENS,
        )
    finally:
        if old_key is None:
            os.environ.pop("DASHSCOPE_API_KEY", None)
        else:
            os.environ["DASHSCOPE_API_KEY"] = old_key

    assert str(observed["url"]).endswith("/chat/completions")
    assert observed["payload"]["temperature"] == TEMPERATURE
    assert observed["payload"]["top_p"] == TOP_P
    assert observed["payload"]["max_tokens"] == STRATEGY_MAX_TOKENS
    assert observed["payload"]["enable_thinking"] is False
    assert result.total_tokens == result.prompt_tokens + result.completion_tokens
    return result
