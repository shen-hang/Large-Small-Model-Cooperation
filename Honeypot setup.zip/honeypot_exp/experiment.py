"""Core execution and evaluation for the three-method paired experiment."""

from __future__ import annotations

from dataclasses import dataclass
import shlex
from typing import Callable, Mapping, Sequence

from config import (
    BASELINE_MODEL_NAME,
    COORDINATION_PROMPT,
    HONEYPOT_SYSTEM_PROMPT,
    METHODS,
    PROPOSED_MODEL_NAME,
    STRATEGY_MAX_TOKENS,
    STRATEGY_SYSTEM_PROMPT,
)
from model import ChatResult, Message, chat
from tasks import AttackStep, AttackTask


ChatFunction = Callable[..., ChatResult]

METHOD_MODELS = {
    "Baseline-2": BASELINE_MODEL_NAME,
    "Proposed-2": PROPOSED_MODEL_NAME,
    "Proposed-5": PROPOSED_MODEL_NAME,
}

_SHELL_PROGRAMS = {
    "cat", "curl", "docker", "find", "grep", "ip", "mosquitto_pub",
    "head", "mosquitto_sub", "mysql", "nc", "nmap", "ssh", "sudo", "uname",
}
_AI_EXPOSURE_MARKERS = (
    "as an ai", "language model", "i cannot assist", "i can't assist",
    "honeypot", "simulated response", "i cannot execute", "i can't execute",
)


@dataclass(frozen=True)
class TurnResult:
    task_id: str
    method: str
    round_number: int
    stage: str
    tier: str
    command: str
    response: str
    command_valid: bool
    ai_exposure: bool
    evidence_matched: tuple[str, ...]
    success: bool
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass(frozen=True)
class SessionResult:
    task_id: str
    method: str
    model_name: str
    attack_depth: int
    session_rounds: int
    completed: bool
    termination_reason: str
    interaction_prompt_tokens: int
    interaction_completion_tokens: int
    interaction_tokens: int
    coordination_prompt_tokens: int
    coordination_completion_tokens: int
    coordination_tokens: int
    overall_tokens: int
    strategy: str | None
    turns: tuple[TurnResult, ...]

    def __post_init__(self) -> None:
        # Baseline-3 is an archived DeepSeek run reused for reporting only; it
        # is intentionally absent from METHODS so the CLI never calls it.
        if self.method not in (*METHODS, "Baseline-3"):
            raise ValueError(f"unknown method: {self.method}")
        if self.session_rounds != len(self.turns):
            raise ValueError("session_rounds must equal the number of turns")
        if self.overall_tokens != self.interaction_tokens + self.coordination_tokens:
            raise ValueError("overall token accounting is inconsistent")
        if self.method != "Proposed-5" and self.coordination_tokens != 0:
            raise ValueError("only Proposed-5 may consume coordination tokens")


def is_valid_shell_command(command: str) -> bool:
    """Conservatively validate syntax without ever executing the command."""

    if not command or len(command) > 1000 or any(char in command for char in "\x00\r\n"):
        return False
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=";&|")
        lexer.whitespace_split = True
        lexer.commenters = ""
        tokens = list(lexer)
    except ValueError:
        return False
    if not tokens:
        return False

    expecting_executable = True
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token in {";", "&&", "|"}:
            if expecting_executable:
                return False
            expecting_executable = True
            index += 1
            continue
        if expecting_executable:
            executable = token
            if executable == "sudo":
                nested_index = index + 1
                while nested_index < len(tokens) and tokens[nested_index].startswith("-"):
                    nested_index += 1
                # `sudo -l` and similar inspection commands are complete
                # without a nested executable.
                if nested_index < len(tokens) and tokens[nested_index] not in {";", "&&", "|"}:
                    executable = tokens[nested_index]
                    index = nested_index
            if executable not in _SHELL_PROGRAMS:
                return False
            expecting_executable = False
        index += 1
    return not expecting_executable


def detects_ai_exposure(response: str) -> bool:
    lowered = response.casefold()
    return any(marker in lowered for marker in _AI_EXPOSURE_MARKERS)


def _matched_evidence(response: str, step: AttackStep) -> tuple[str, ...]:
    lowered = response.casefold()
    return tuple(item for item in step.success_evidence if item.casefold() in lowered)


def _local_context(task: AttackTask, step: AttackStep) -> str:
    # Identical for Proposed-2 and Proposed-5.  No cross-tier observations or
    # strategy atoms are included here, preventing an initial-config confound.
    return (
        f"Local node profile: tier={step.tier}; task_family={task.family}; "
        f"attacker_profile={task.attacker_profile}. Preserve only this node's "
        "conversation state and return realistic command output."
    )


class ExperimentRunner:
    def __init__(self, chat_function: ChatFunction = chat) -> None:
        self._chat = chat_function

    def generate_strategy(self, task: AttackTask) -> ChatResult:
        route = " -> ".join(step.tier for step in task.steps)
        chain = "\n".join(
            f"{index}. {step.stage} at {step.tier}: {step.command}"
            for index, step in enumerate(task.steps, start=1)
        )
        messages = [
            {"role": "system", "content": STRATEGY_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    f"Task {task.task_id}; family={task.family}; route={route}.\n"
                    f"Attack chain:\n{chain}"
                ),
            },
        ]
        return self._chat(
            messages,
            PROPOSED_MODEL_NAME,
            max_tokens=STRATEGY_MAX_TOKENS,
        )

    def run(self, task: AttackTask, method: str) -> SessionResult:
        if method not in METHOD_MODELS:
            raise ValueError(f"method must be one of {', '.join(METHODS)}")
        model_name = METHOD_MODELS[method]
        strategy_result: ChatResult | None = None
        if method == "Proposed-5":
            strategy_result = self.generate_strategy(task)

        # Each tier represents a separate node.  Local history is not silently
        # shared across nodes; Proposed-5 coordinates them only via strategy.
        node_histories: dict[str, list[dict[str, str]]] = {}
        turns: list[TurnResult] = []
        interaction_prompt = 0
        interaction_completion = 0
        interaction_total = 0
        attack_depth = 0
        termination_reason = "completed"

        for round_number, step in enumerate(task.steps, start=1):
            command_valid = is_valid_shell_command(step.command)
            if not command_valid:
                termination_reason = "invalid_attack_command"
                break

            history = node_histories.setdefault(step.tier, [])
            messages: list[dict[str, str]] = [
                {"role": "system", "content": HONEYPOT_SYSTEM_PROMPT},
                {"role": "system", "content": _local_context(task, step)},
            ]
            if strategy_result is not None:
                messages.append(
                    {
                        "role": "system",
                        "content": COORDINATION_PROMPT.format(strategy=strategy_result.content),
                    }
                )
            messages.extend(history)
            messages.append({"role": "user", "content": step.command})
            response = self._chat(messages, model_name)
            interaction_prompt += response.prompt_tokens
            interaction_completion += response.completion_tokens
            interaction_total += response.total_tokens

            exposed = detects_ai_exposure(response.content)
            evidence = _matched_evidence(response.content, step)
            success = command_valid and not exposed and bool(evidence)
            turns.append(
                TurnResult(
                    task_id=task.task_id,
                    method=method,
                    round_number=round_number,
                    stage=step.stage,
                    tier=step.tier,
                    command=step.command,
                    response=response.content,
                    command_valid=command_valid,
                    ai_exposure=exposed,
                    evidence_matched=evidence,
                    success=success,
                    prompt_tokens=response.prompt_tokens,
                    completion_tokens=response.completion_tokens,
                    total_tokens=response.total_tokens,
                )
            )
            history.extend(
                [
                    {"role": "user", "content": step.command},
                    {"role": "assistant", "content": response.content},
                ]
            )
            if not success:
                termination_reason = "ai_exposure" if exposed else "missing_stage_evidence"
                break
            attack_depth = round_number

        coordination_prompt = strategy_result.prompt_tokens if strategy_result else 0
        coordination_completion = strategy_result.completion_tokens if strategy_result else 0
        coordination_total = strategy_result.total_tokens if strategy_result else 0
        return SessionResult(
            task_id=task.task_id,
            method=method,
            model_name=model_name,
            attack_depth=attack_depth,
            session_rounds=len(turns),
            completed=attack_depth == len(task.steps),
            termination_reason=termination_reason,
            interaction_prompt_tokens=interaction_prompt,
            interaction_completion_tokens=interaction_completion,
            interaction_tokens=interaction_total,
            coordination_prompt_tokens=coordination_prompt,
            coordination_completion_tokens=coordination_completion,
            coordination_tokens=coordination_total,
            overall_tokens=interaction_total + coordination_total,
            strategy=strategy_result.content if strategy_result else None,
            turns=tuple(turns),
        )


def run(task: AttackTask, method: str) -> SessionResult:
    """Public execution-plan interface using the configured model client."""

    return ExperimentRunner().run(task, method)


def experiment_smoke_test() -> Mapping[str, SessionResult]:
    """Exercise all Phase-3 branches with a deterministic fake model."""

    from tasks import generate_tasks

    calls: list[tuple[str, Sequence[Message]]] = []

    strategy_options: list[dict[str, object]] = []

    def fake_chat(
        messages: Sequence[Message],
        model_name: str,
        **options: object,
    ) -> ChatResult:
        calls.append((model_name, messages))
        last = messages[-1]["content"]
        if last.startswith("Task "):
            strategy_options.append(options)
            content = "hosts=ground,air,space; credential=deploy; pivot=10.40.3.32"
        elif last.startswith("nmap"):
            content = "22/tcp open ssh OpenSSH_8.9p1"
        elif last.startswith("find"):
            content = "/home/deploy/app.conf\n/home/deploy/.ssh/id_rsa.key"
        elif last.startswith("sudo"):
            content = "User deploy may run sudo /usr/bin/find as root"
        else:
            content = "Last login: Mon Jul 20 09:14:00 from 10.20.1.32"
        return ChatResult(content, 10, 5, 15, model_name, "fake")

    task = generate_tasks(count=1)[0]
    runner = ExperimentRunner(fake_chat)
    results = {method: runner.run(task, method) for method in METHODS}
    assert all(result.attack_depth == 4 for result in results.values())
    assert results["Proposed-2"].model_name == results["Proposed-5"].model_name
    assert results["Proposed-2"].coordination_tokens == 0
    assert results["Proposed-5"].coordination_tokens == 15
    assert results["Proposed-5"].overall_tokens == 75
    assert len(calls) == 13  # 4 + 4 + (1 strategy + 4 interactions)
    assert strategy_options == [{"max_tokens": STRATEGY_MAX_TOKENS}]
    assert all(model == BASELINE_MODEL_NAME for model, _ in calls[:4])
    assert all(model == PROPOSED_MODEL_NAME for model, _ in calls[4:])
    proposed_2_calls = calls[4:8]
    proposed_5_interactions = calls[9:13]
    for (_, messages_2), (_, messages_5) in zip(proposed_2_calls, proposed_5_interactions):
        without_coordination = [
            message
            for message in messages_5
            if not message["content"].startswith("Use the shared cross-tier strategy")
        ]
        assert without_coordination == list(messages_2)
    # T01 pivots from ground to space in round four.  Proposed-2's new node
    # receives no ground-node history, proving histories are node-local.
    assert len(proposed_2_calls[3][1]) == 3
    return results
