# Edge GPT-4o and MCP-RAG overhead probe

This probe is isolated from the main experiment. It never reads or writes the
main checkpoint and writes only to `outputs/system_overhead_probe`.

## 1. Install the official MCP SDK

Use the same Conda environment as the honeypot experiment:

```powershell
python -m pip install --user -r requirements_overhead.txt
```

If Conda does not automatically expose user-level packages, both scripts add
the Python user-site directory to their import path.

## 2. Start the Streamable HTTP MCP server

In the first PowerShell window:

```powershell
cd D:\studyPython2025\test\honeypot_exp
python -B mcp_rag_server.py
```

The endpoint is `http://127.0.0.1:8000/mcp` and the retrieval tool is
`search_strategy_atoms`.

## 3. Validate configuration

In a second PowerShell window:

```powershell
cd D:\studyPython2025\test\honeypot_exp
python -B benchmark_system_overhead.py --dry-run
```

## 4. Test MCP-RAG without spending OpenAI tokens

```powershell
python -B benchmark_system_overhead.py --rag-only --repeats 10 --warmup 1
```

## 5. Run the complete benchmark

Set the OpenAI key in the second PowerShell window:

```powershell
$env:OPENAI_API_KEY="your-key"
```

Then run:

```powershell
python -B benchmark_system_overhead.py `
  --task-id T04 `
  --repeats 10 `
  --warmup 1 `
  --top-k 5
```

Outputs:

- `outputs/system_overhead_probe/request_latency.csv`
- `outputs/system_overhead_probe/overhead_summary.json`

The MCP connection is initialized once. Warm-up calls are excluded from the
reported statistics. Communication sizes are serialized application payloads;
HTTP headers are not included. The edge and end-to-end measurements use
client-observed wall-clock latency.
