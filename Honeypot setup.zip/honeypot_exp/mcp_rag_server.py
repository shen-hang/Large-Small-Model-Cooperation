"""MCP Streamable HTTP server for strategy-atom retrieval benchmarks."""

from __future__ import annotations

import argparse
import asyncio
from collections import Counter
import json
import math
from pathlib import Path
import re
import site
import sys
from time import perf_counter_ns
from typing import Any


# Some Conda installations do not automatically add the per-user site directory.
_USER_SITE = site.getusersitepackages()
if _USER_SITE and _USER_SITE not in sys.path:
    sys.path.append(_USER_SITE)

try:
    from mcp.server.fastmcp import FastMCP
except ImportError as exc:  # pragma: no cover - exercised by deployment setup
    raise SystemExit(
        "The official MCP SDK is required. Run: python -m pip install --user "
        "mcp==1.29.0"
    ) from exc


PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_ATOM_PATH = PROJECT_DIR / "strategy_atoms.json"
TOKEN_PATTERN = re.compile(r"[a-z0-9_.-]+")


def _tokenize(value: str) -> list[str]:
    return TOKEN_PATTERN.findall(value.casefold())


class AtomIndex:
    """Small deterministic BM25 index used behind the MCP tool."""

    def __init__(self, path: Path) -> None:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, list) or not raw:
            raise ValueError("strategy atom file must contain a non-empty JSON list")
        self.atoms: list[dict[str, Any]] = raw
        self.documents = [
            _tokenize(
                " ".join(
                    [
                        str(atom["category"]),
                        str(atom["content"]),
                        *map(str, atom["keywords"]),
                        *map(str, atom["tiers"]),
                        *map(str, atom["stages"]),
                    ]
                )
            )
            for atom in self.atoms
        ]
        self.lengths = [len(document) for document in self.documents]
        self.average_length = sum(self.lengths) / len(self.lengths)
        document_frequency: Counter[str] = Counter()
        for document in self.documents:
            document_frequency.update(set(document))
        self.idf = {
            token: math.log(
                1 + (len(self.documents) - frequency + 0.5) / (frequency + 0.5)
            )
            for token, frequency in document_frequency.items()
        }

    def search(
        self,
        threat_summary: str,
        attack_stage: str,
        source_tier: str,
        target_tiers: list[str],
        top_k: int,
    ) -> list[dict[str, Any]]:
        query_tokens = _tokenize(
            " ".join([threat_summary, attack_stage, source_tier, *target_tiers])
        )
        query_frequency = Counter(query_tokens)
        scored: list[tuple[float, dict[str, Any]]] = []
        k1, b = 1.5, 0.75
        for atom, document, length in zip(
            self.atoms, self.documents, self.lengths
        ):
            term_frequency = Counter(document)
            score = 0.0
            for token, query_count in query_frequency.items():
                frequency = term_frequency[token]
                if frequency == 0:
                    continue
                denominator = frequency + k1 * (
                    1 - b + b * length / self.average_length
                )
                score += (
                    self.idf.get(token, 0.0)
                    * frequency
                    * (k1 + 1)
                    / denominator
                    * min(query_count, 2)
                )
            tier_overlap = set([source_tier, *target_tiers]) & set(atom["tiers"])
            if tier_overlap:
                score += 0.25 * len(tier_overlap)
            if attack_stage in atom["stages"]:
                score += 0.35
            scored.append((score, atom))
        scored.sort(key=lambda item: (-item[0], str(item[1]["atom_id"])))
        return [
            {
                "atom_id": atom["atom_id"],
                "category": atom["category"],
                "content": atom["content"],
                "score": round(score, 6),
                "tiers": atom["tiers"],
                "stages": atom["stages"],
            }
            for score, atom in scored[:top_k]
        ]


def build_server(
    atom_path: Path,
    host: str = "127.0.0.1",
    port: int = 8000,
) -> FastMCP:
    index = AtomIndex(atom_path)
    server = FastMCP(
        "SAGVN Strategy Atom RAG",
        instructions=(
            "Retrieve host, service, credential, file and pivot strategy atoms "
            "for cross-tier honeypot orchestration."
        ),
        host=host,
        port=port,
        streamable_http_path="/mcp",
        stateless_http=True,
        json_response=True,
    )

    @server.tool()
    def search_strategy_atoms(
        threat_summary: str,
        attack_stage: str,
        source_tier: str,
        target_tiers: list[str],
        top_k: int = 5,
    ) -> dict[str, Any]:
        """Retrieve the top-k strategy atoms for one cross-tier threat."""

        if not threat_summary.strip():
            raise ValueError("threat_summary must not be empty")
        if source_tier not in {"ground", "air", "space"}:
            raise ValueError("source_tier must be ground, air or space")
        if not set(target_tiers).issubset({"ground", "air", "space"}):
            raise ValueError("target_tiers contains an unknown tier")
        if not 1 <= top_k <= 10:
            raise ValueError("top_k must be between 1 and 10")
        started_ns = perf_counter_ns()
        atoms = index.search(
            threat_summary,
            attack_stage,
            source_tier,
            target_tiers,
            top_k,
        )
        compute_ms = (perf_counter_ns() - started_ns) / 1_000_000
        return {
            "atoms": atoms,
            "retrieval_count": len(atoms),
            "retrieval_compute_ms": round(compute_ms, 6),
            "knowledge_base_atoms": len(index.atoms),
            "knowledge_base_version": "sagvn-atoms-v1",
        }

    return server


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the strategy-atom MCP RAG server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--atom-file", type=Path, default=DEFAULT_ATOM_PATH)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    server = build_server(args.atom_file.resolve(), args.host, args.port)
    print(f"MCP RAG server: http://{args.host}:{args.port}/mcp")
    print(f"Strategy atoms: {args.atom_file.resolve()}")
    try:
        server.run(transport="streamable-http")
    except (KeyboardInterrupt, asyncio.CancelledError):
        print("MCP RAG server stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
