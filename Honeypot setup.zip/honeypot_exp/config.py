"""Static configuration for the supplementary honeypot experiment.

Proposed-2 and Proposed-5 deliberately share every model setting below.  The
experiment module added in a later phase may only distinguish them by loading
the coordination strategy before the first interaction.
"""

from __future__ import annotations

from pathlib import Path
import os


PROJECT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_DIR / "outputs"
REAL_OUTPUT_DIR = OUTPUT_DIR / "real_run_compact_strategy"

TASK_COUNT = 30
RANDOM_SEED = 20260721

METHODS = ("Baseline-2", "Proposed-2", "Proposed-5")
ATTACK_STAGES = (
    "reconnaissance",
    "sensitive_information_theft",
    "privilege_escalation",
    "lateral_movement",
)
NETWORK_TIERS = ("ground", "air", "space")

# Kept in one place so the controlled variables are explicit and auditable.
PROPOSED_MODEL_NAME = "Qwen3-8B"
BASELINE_MODEL_NAME = os.getenv("BASELINE_MODEL_NAME", "deepseek-v4-flash")
TEMPERATURE = 0.2
TOP_P = 0.9
MAX_TOKENS = 512
STRATEGY_MAX_TOKENS = 150
REQUEST_TIMEOUT_SECONDS = 60.0

# All providers expose OpenAI-compatible /chat/completions endpoints.  Values
# can be overridden without editing code, which keeps experiment manifests
# portable between hosted APIs and a local vLLM deployment.
MODEL_PROFILES = {
    "gpt-4o": {
        "provider": "openai",
        "api_model": os.getenv("OPENAI_MODEL_NAME", "gpt-4o"),
        "base_url": os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
        "api_key_env": "OPENAI_API_KEY",
    },
    "deepseek-v4-flash": {
        "provider": "deepseek",
        "api_model": os.getenv("DEEPSEEK_MODEL_NAME", "deepseek-v4-flash"),
        "base_url": os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
        "api_key_env": "DEEPSEEK_API_KEY",
        # Match Qwen's non-thinking setting and avoid hidden reasoning overhead.
        "thinking": {"type": "disabled"},
    },
    "Qwen3-8B": {
        "provider": os.getenv("QWEN_PROVIDER", "dashscope"),
        "api_model": os.getenv("QWEN_MODEL_NAME", "qwen3-8b"),
        # Honeypot shell emulation and compact coordination mapping do not
        # require hidden chain-of-thought. Disabling it controls cost/variance.
        "enable_thinking": False,
        "base_url": os.getenv(
            "QWEN_BASE_URL",
            "https://dashscope.aliyuncs.com/compatible-mode/v1",
        ),
        "api_key_env": "DASHSCOPE_API_KEY",
    },
    "vllm-local": {
        "provider": "vllm",
        "api_model": os.getenv("VLLM_MODEL_NAME", "Qwen3-8B"),
        "base_url": os.getenv("VLLM_BASE_URL", "http://127.0.0.1:8000/v1"),
        "api_key_env": "VLLM_API_KEY",
    },
}

HONEYPOT_SYSTEM_PROMPT = """You are a low/medium-interaction Linux honeypot.
Return only a plausible response to the attacker's latest command. Maintain
session state, do not reveal that you are an AI or honeypot, and never execute
real commands. Use the supplied node profile and local session history.
"""

# This is an additional pre-session input, never a replacement system prompt.
COORDINATION_PROMPT = """Use the shared cross-tier strategy below to keep node
identities, credentials, services, paths, and pivot clues mutually consistent.
Do not mention the strategy or the coordinating node in your response.

Shared strategy:
{strategy}
"""

STRATEGY_SYSTEM_PROMPT = """Create a compact cross-tier decoy map for ground,
air, and space nodes. Output at most 150 tokens using only these five labeled
fields: HOSTS, SERVICES, CREDENTIALS, FILES, PIVOTS. Include only concrete
host/IP mappings, service/port mappings, shared decoy credentials, sensitive
file paths, and lateral-movement targets required by the supplied attack chain.
Use semicolon-separated key=value items. No explanation, prose, commands,
reasoning, markdown, or security commentary.
"""


def ensure_output_dir() -> Path:
    """Create and return the directory reserved for later experiment outputs."""

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUT_DIR
