"""Command-line entry point for the supplementary experiment."""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
from typing import Iterable

from config import (
    METHODS,
    MODEL_PROFILES,
    OUTPUT_DIR,
    RANDOM_SEED,
    REAL_OUTPUT_DIR,
    TASK_COUNT,
)
from experiment import (
    METHOD_MODELS,
    ExperimentRunner,
    SessionResult,
    TurnResult,
    experiment_smoke_test,
)
from model import smoke_test
from reporter import report
from tasks import AttackTask, generate_tasks, validate_task_suite


def _print_task(task: AttackTask) -> None:
    route = " -> ".join(step.tier for step in task.steps)
    print(
        f"{task.task_id} | {task.family} | {task.deployment_window} | "
        f"route: {route} | attacker: {task.attacker_profile}"
    )
    for number, step in enumerate(task.steps, start=1):
        evidence = ", ".join(step.success_evidence)
        print(f"  {number}. {step.stage} [{step.tier}]: {step.command}")
        print(f"     expected evidence: {evidence}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="LLM honeypot supplementary experiment")
    parser.add_argument(
        "--tasks-only",
        action="store_true",
        help="generate, validate, and print the fixed attack-task suite",
    )
    parser.add_argument(
        "--smoke-test",
        action="store_true",
        help="test the model interface locally without contacting an API",
    )
    parser.add_argument(
        "--experiment-smoke-test",
        action="store_true",
        help="test all Phase-3 experiment branches without contacting an API",
    )
    parser.add_argument(
        "--reporter-smoke-test",
        action="store_true",
        help="generate Phase-4 CSVs and figures from deterministic offline data",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="validate a real-run configuration without calling any API",
    )
    parser.add_argument(
        "--run",
        action="store_true",
        help="execute the real three-method experiment using configured APIs",
    )
    parser.add_argument(
        "--methods",
        nargs="+",
        choices=METHODS,
        default=list(METHODS),
        help="methods included in --run/--dry-run (default: all)",
    )
    parser.add_argument(
        "--task-limit",
        type=int,
        default=TASK_COUNT,
        help="number of deterministic tasks to run (1-30)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REAL_OUTPUT_DIR,
        help="directory for real results and checkpoint",
    )
    parser.add_argument(
        "--no-resume",
        action="store_true",
        help="ignore an existing checkpoint (fails if it already exists)",
    )
    parser.add_argument("--seed", type=int, default=RANDOM_SEED, help="task generation seed")
    return parser


def _required_profiles(methods: Iterable[str]) -> tuple[tuple[str, dict[str, str]], ...]:
    seen: set[str] = set()
    profiles = []
    for method in methods:
        model_name = METHOD_MODELS[method]
        if model_name not in seen:
            seen.add(model_name)
            profiles.append((model_name, MODEL_PROFILES[model_name]))
    return tuple(profiles)


def _preflight(methods: tuple[str, ...], task_limit: int) -> list[str]:
    if not 1 <= task_limit <= TASK_COUNT:
        raise ValueError(f"--task-limit must be between 1 and {TASK_COUNT}")
    problems: list[str] = []
    print("Real-run preflight (no API calls):")
    print(f"  tasks={task_limit}, methods={', '.join(methods)}")
    maximum_calls = task_limit * sum(5 if method == "Proposed-5" else 4 for method in methods)
    print(f"  maximum API calls={maximum_calls} (early termination may reduce this)")
    for model_name, profile in _required_profiles(methods):
        provider = str(profile["provider"])
        key_env = str(profile["api_key_env"])
        key_required = provider != "vllm"
        key_present = bool(os.getenv(key_env))
        print(
            f"  {model_name}: provider={provider}, api_model={profile['api_model']}, "
            f"base_url={profile['base_url']}, {key_env}={'set' if key_present else 'missing'}"
        )
        if key_required and not key_present:
            problems.append(f"{key_env} is required for {model_name}")
    if problems:
        print("Preflight failed:")
        for problem in problems:
            print(f"  - {problem}")
    else:
        print("Preflight passed.")
    return problems


def _session_from_dict(data: dict[str, object]) -> SessionResult:
    turn_data = data.pop("turns")
    if not isinstance(turn_data, list):
        raise ValueError("checkpoint turns must be a list")
    turns = []
    for raw_turn in turn_data:
        if not isinstance(raw_turn, dict):
            raise ValueError("checkpoint turn must be an object")
        raw_turn["evidence_matched"] = tuple(raw_turn["evidence_matched"])
        turns.append(TurnResult(**raw_turn))
    data["turns"] = tuple(turns)
    return SessionResult(**data)


def _load_checkpoint(path: Path) -> dict[tuple[str, str], SessionResult]:
    completed: dict[tuple[str, str], SessionResult] = {}
    if not path.exists():
        return completed
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                result = _session_from_dict(json.loads(line))
            except (json.JSONDecodeError, TypeError, ValueError, KeyError) as exc:
                raise ValueError(f"invalid checkpoint line {line_number}: {exc}") from exc
            key = (result.task_id, result.method)
            if key in completed:
                raise ValueError(f"duplicate checkpoint result: {key}")
            completed[key] = result
    return completed


def _append_checkpoint(path: Path, result: SessionResult) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(asdict(result), ensure_ascii=False) + "\n")
        handle.flush()


def _run_real_experiment(
    tasks: tuple[AttackTask, ...],
    methods: tuple[str, ...],
    output_dir: Path,
    resume: bool,
    runner: ExperimentRunner | None = None,
) -> tuple[SessionResult, ...]:
    checkpoint_path = output_dir / "checkpoint.jsonl"
    if not resume and checkpoint_path.exists():
        raise FileExistsError(
            f"{checkpoint_path} already exists; remove/move it or omit --no-resume"
        )
    completed = _load_checkpoint(checkpoint_path) if resume else {}
    requested = {(task.task_id, method) for task in tasks for method in methods}
    results = {key: value for key, value in completed.items() if key in requested}
    runner = runner or ExperimentRunner()
    total = len(requested)
    print(f"Starting/resuming real experiment: {len(results)}/{total} sessions complete.")

    for task in tasks:
        for method in methods:
            key = (task.task_id, method)
            if key in results:
                print(f"[{len(results):03d}/{total:03d}] skip {task.task_id} {method}")
                continue
            print(f"[{len(results) + 1:03d}/{total:03d}] run  {task.task_id} {method}")
            result = runner.run(task, method)
            _append_checkpoint(checkpoint_path, result)
            results[key] = result
            print(
                f"    depth={result.attack_depth}, rounds={result.session_rounds}, "
                f"tokens={result.overall_tokens}, stop={result.termination_reason}"
            )

    ordered = tuple(results[(task.task_id, method)] for task in tasks for method in methods)
    paths = report(ordered, output_dir)
    print("Real experiment complete. Generated:")
    for path in paths:
        print(f"  {path}")
    return ordered


def main() -> int:
    args = build_parser().parse_args()
    selected = sum(
        (
            args.tasks_only,
            args.smoke_test,
            args.experiment_smoke_test,
            args.reporter_smoke_test,
            args.dry_run,
            args.run,
        )
    )
    if selected != 1:
        build_parser().error(
            "choose exactly one of --tasks-only, --smoke-test, "
            "--experiment-smoke-test, --reporter-smoke-test, --dry-run, or --run"
        )

    methods = tuple(args.methods)
    if args.dry_run or args.run:
        try:
            problems = _preflight(methods, args.task_limit)
        except ValueError as exc:
            build_parser().error(str(exc))
        if problems:
            return 2
        if args.dry_run:
            return 0
        tasks = generate_tasks(count=TASK_COUNT, seed=args.seed)[: args.task_limit]
        validate_task_suite(generate_tasks(count=TASK_COUNT, seed=args.seed))
        _run_real_experiment(tasks, methods, args.output_dir.resolve(), not args.no_resume)
        return 0

    if args.reporter_smoke_test:
        tasks = generate_tasks(count=TASK_COUNT, seed=args.seed)
        synthetic = []
        target_depth = {"Baseline-2": 2, "Proposed-2": 3, "Proposed-5": 4}
        for method in ("Baseline-2", "Proposed-2", "Proposed-5"):
            for index, task in enumerate(tasks):
                depth = min(4, target_depth[method] + (1 if index % 5 == 0 else 0))
                turns = tuple(
                    TurnResult(
                        task_id=task.task_id, method=method, round_number=number,
                        stage=step.stage, tier=step.tier, command=step.command,
                        response=step.success_evidence[0], command_valid=True,
                        ai_exposure=False, evidence_matched=(step.success_evidence[0],),
                        success=True, prompt_tokens=20, completion_tokens=10,
                        total_tokens=30,
                    )
                    for number, step in enumerate(task.steps[:depth], start=1)
                )
                coordination = 18 if method == "Proposed-5" else 0
                interaction = 30 * depth
                synthetic.append(
                    SessionResult(
                        task_id=task.task_id, method=method,
                        model_name="gpt-4o" if method == "Baseline-2" else "Qwen3-8B",
                        attack_depth=depth, session_rounds=depth, completed=depth == 4,
                        termination_reason="completed" if depth == 4 else "missing_stage_evidence",
                        interaction_prompt_tokens=20 * depth,
                        interaction_completion_tokens=10 * depth,
                        interaction_tokens=interaction,
                        coordination_prompt_tokens=12 if coordination else 0,
                        coordination_completion_tokens=6 if coordination else 0,
                        coordination_tokens=coordination,
                        overall_tokens=interaction + coordination,
                        strategy="offline shared strategy" if coordination else None,
                        turns=turns,
                    )
                )
        paths = report(synthetic, OUTPUT_DIR / "smoke_test")
        for path in paths:
            print(path)
        print("Reporter smoke test passed.")
        return 0

    if args.experiment_smoke_test:
        results = experiment_smoke_test()
        for method, result in results.items():
            print(
                f"{method}: depth={result.attack_depth}, rounds={result.session_rounds}, "
                f"interaction_tokens={result.interaction_tokens}, "
                f"coordination_tokens={result.coordination_tokens}, "
                f"overall_tokens={result.overall_tokens}"
            )
        print("Experiment smoke test passed.")
        return 0

    if args.smoke_test:
        result = smoke_test()
        print(
            "Model smoke test passed: "
            f"provider={result.provider}, model={result.model}, "
            f"prompt_tokens={result.prompt_tokens}, "
            f"completion_tokens={result.completion_tokens}, "
            f"total_tokens={result.total_tokens}"
        )
        return 0

    tasks = generate_tasks(count=TASK_COUNT, seed=args.seed)
    validate_task_suite(tasks)
    for task in tasks:
        _print_task(task)
    print(f"Generated and validated {len(tasks)} tasks (seed={args.seed}).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
