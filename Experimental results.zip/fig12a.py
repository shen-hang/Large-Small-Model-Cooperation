"""Standalone script: reproduce Figure 3-11a — Round vs time(ms).
Data extracted from task2.xlsx.
"""

import matplotlib.pyplot as plt
import numpy as np

# ===========================================================================
# Data from task2.xlsx (Fig3-11a)
# ===========================================================================
rounds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

vehicle = [7.5,  7.5,  7.96, 6.56, 6.68, 7.43, 7.14, 8.0,  7.21, 6.88]   # 地链
drone   = [7.92, 6.88, 9.43, 7.14, 7.52, 7.25, 8.1,  7.36, 7.68, 6.95]   # 空链
satellite = [7.64, 7.76, 7.58, 6.82, 7.12, 8.05, 7.02, 8.7,  7.11, 7.33]  # 天链

# ===========================================================================
# Global style — matching plot_3_9a.py
# ===========================================================================
plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 20,
    "axes.labelsize": 24,
    "axes.linewidth": 1.2,
    "axes.spines.top": True,
    "axes.spines.right": True,
    "axes.grid": True,
    "axes.axisbelow": True,
    "xtick.labelsize": 20,
    "ytick.labelsize": 20,
    "xtick.major.width": 1.2,
    "ytick.major.width": 1.2,
    "xtick.major.size": 7,
    "ytick.major.size": 7,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "grid.linewidth": 0.9,
    "grid.linestyle": "--",
    "grid.alpha": 0.4,
    "legend.fontsize": 30,
    "figure.dpi": 150,
    "savefig.dpi": 600,
})

# ===========================================================================
# Plot
# ===========================================================================
colors = {
    'vehicle':   '#2ca02c',
    'drone':     '#ff7f0e',
    'satellite': '#1f77b4',
}
markers = {
    'vehicle':   's',
    'drone':     'o',
    'satellite': '^',
}
linestyles = {
    'vehicle':   '-',
    'drone':     ':',
    'satellite': '--',
}

fig, ax = plt.subplots(figsize=(10, 7))

ax.plot(rounds, vehicle,   label='vehicle',   color=colors['vehicle'],   marker=markers['vehicle'],   linestyle=linestyles['vehicle'],   markerfacecolor='none', markersize=7, linewidth=2.0)
ax.plot(rounds, drone,     label='drone',     color=colors['drone'],     marker=markers['drone'],     linestyle=linestyles['drone'],     markerfacecolor='none', markersize=7, linewidth=2.0)
ax.plot(rounds, satellite, label='satellite', color=colors['satellite'], marker=markers['satellite'], linestyle=linestyles['satellite'], markerfacecolor='none', markersize=7, linewidth=2.0)

# --- Axes ---
ax.set_xlabel("Task rounds", fontsize=30)
ax.set_ylabel("time(ms)", fontsize=30)
ax.set_xlim(1, 10)
ax.set_ylim(6, 11)

# --- Legend & grid ---
ax.legend(fontsize=30, frameon=True)
ax.grid(True, linestyle='--', alpha=0.4)

# --- Save ---
fig.tight_layout()
fig.savefig("Fig3-11a.pdf", format='pdf', dpi=600, bbox_inches='tight', facecolor="white")
fig.savefig("Fig3-11a.png", dpi=600, bbox_inches='tight', facecolor="white")
print("Saved: Fig3-11a.pdf, Fig3-11a.png")
plt.close(fig)
