"""
Standalone script: reproduce Figure 11 — average group reward per round
across three mechanisms (Baseline-4, Baseline-5, Proposed-5).

Style follows Figure 3-9 / Figure 3-10:
- Same physical figure size as Figure 3-9 / 3-10
- Same Times New Roman font configuration
- Same axis / grid / tick style
- Figure is shifted slightly downward to align with Figure 3-10

Outputs:
    fig11.png
    fig11.pdf

Usage:
    python fig11.py
"""

from __future__ import annotations

import io

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Global plotting configuration
# Matching Figure 3-9 / Figure 3-10
# ---------------------------------------------------------------------------

plt.rcParams.update({

    "font.family": "Times New Roman",

    "font.size": 20,

    "axes.labelsize": 24,

    "axes.linewidth": 1.4,

    "axes.spines.top": True,
    "axes.spines.right": True,

    "axes.grid": True,
    "axes.axisbelow": True,

    "xtick.labelsize": 18,
    "ytick.labelsize": 18,

    "xtick.major.width": 1.2,
    "ytick.major.width": 1.2,

    "xtick.major.size": 7,
    "ytick.major.size": 7,

    "xtick.direction": "out",
    "ytick.direction": "out",

    "grid.linewidth": 0.8,
    "grid.linestyle": "--",
    "grid.alpha": 0.4,

    "legend.fontsize": 20,

    "figure.dpi": 150,
    "savefig.dpi": 600,

    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


# ---------------------------------------------------------------------------
# Figure size
#
# IMPORTANT:
# Use exactly the same physical size as Figure 3-9 / Figure 3-10.
#
# This corresponds to:
#     figsize=(690.87625 / 72, 474.6850106476 / 72)
#
# Do NOT use figsize=(10, 7), otherwise Figure 11 becomes larger.
# ---------------------------------------------------------------------------

TARGET_SIZE_INCHES = (
    690.87625 / 72.0,
    474.6850106476 / 72.0,
)


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

csv_data = """mechanism,High-value,Novelty-oriented,Effectiveness-oriented,Medium-value,Low-value,Unreliable,total
Baseline-4 ,4.355769,4.364863,2.053699,3.334894,1.533133,4.357643,20.000000
Baseline-5,5.146478,3.362106,3.368797,3.166916,1.055811,3.899892,20.000000
Proposed-5 ,6.518232,3.002080,3.014650,3.765082,0.519555,3.180401,20.000000"""


df = pd.read_csv(
    io.StringIO(csv_data)
)

df.columns = [
    c.strip()
    for c in df.columns
]

df["mechanism"] = (
    df["mechanism"]
    .str.strip()
)


# ---------------------------------------------------------------------------
# Categories
# ---------------------------------------------------------------------------

categories = [
    "High-value",
    "Novelty-oriented",
    "Effectiveness-oriented",
    "Medium-value",
    "Low-value",
    "Unreliable",
]


data_values = df[categories].values.T


mechanisms = [
    "Baseline-4",
    "Baseline-5",
    "Proposed-5",
]


# ---------------------------------------------------------------------------
# Bar styles
# Matching the previous Figure 3-7 / Figure 11 style
# ---------------------------------------------------------------------------

COLORS = [
    "#D9E1E8",   # Baseline-4
    "#E8C8C8",   # Baseline-5
    "#C8D9CC",   # Proposed-5
]


HATCHES = [
    "///",
    "...",
    "xxx",
]


EDGECOLOR = "#444444"


# ---------------------------------------------------------------------------
# Estimated error bars
# ---------------------------------------------------------------------------

estimated_errors = np.array([

    [0.05, 0.15, 0.20],

    [0.05, 0.10, 0.10],

    [0.05, 0.10, 0.10],

    [0.05, 0.10, 0.15],

    [0.05, 0.05, 0.05],

    [0.05, 0.30, 0.35],

]).T


# ---------------------------------------------------------------------------
# Figure
#
# IMPORTANT:
# Use the same physical size as Figure 3-9 / Figure 3-10.
# ---------------------------------------------------------------------------

fig, ax = plt.subplots(
    figsize=TARGET_SIZE_INCHES
)


# ---------------------------------------------------------------------------
# Bar positions
# ---------------------------------------------------------------------------

bar_width = 0.25

index = np.arange(
    len(categories)
)


# ---------------------------------------------------------------------------
# Draw bars
# ---------------------------------------------------------------------------

for i, mechanism in enumerate(mechanisms):

    offset = (
        i - 1
    ) * bar_width

    ax.bar(

        index + offset,

        data_values[:, i],

        bar_width,

        yerr=estimated_errors[i],

        label=mechanism,

        color=COLORS[i],

        hatch=HATCHES[i],

        edgecolor=EDGECOLOR,

        linewidth=1.2,

        capsize=4,

        error_kw={
            "elinewidth": 1.2,
            "ecolor": "black",
            "capthick": 1.2,
        },
    )


# ---------------------------------------------------------------------------
# X axis
# ---------------------------------------------------------------------------

ax.set_xticks(
    index
)

ax.set_xticklabels(
    [
        "High-value",
        "Novelty",
        "Effectiveness",
        "Medium-value",
        "Low-value",
        "Unreliable",
    ],
    fontsize=12,
)


# ---------------------------------------------------------------------------
# Y axis
# ---------------------------------------------------------------------------

ax.set_ylabel(
    "Average group reward per round",
    fontsize=26,
)


ax.set_ylim(
    0,
    7.0
)


ax.set_yticks(
    np.arange(
        0,
        7,
        1
    )
)


# ---------------------------------------------------------------------------
# Tick style
# ---------------------------------------------------------------------------

ax.tick_params(
    axis="y",
    labelsize=18
)

ax.tick_params(
    axis="x",
    labelsize=16
)


for tick_label in (
    *ax.get_xticklabels(),
    *ax.get_yticklabels()
):

    tick_label.set_fontname(
        "Times New Roman"
    )


# ---------------------------------------------------------------------------
# Grid
# Matching Figure 3-9 / Figure 3-10
# ---------------------------------------------------------------------------

ax.yaxis.grid(
    True,
    linestyle="--",
    alpha=0.4,
)

ax.xaxis.grid(
    False
)


# ---------------------------------------------------------------------------
# Legend
# ---------------------------------------------------------------------------

ax.legend(

    loc="upper right",

    fontsize=20,

    frameon=True,

    edgecolor="#cccccc",

    fancybox=True,

    borderpad=0.8,
)


# ---------------------------------------------------------------------------
# Layout
#
# First perform normal tight layout.
# Then reduce "top" slightly so that the plotting area moves downward.
#
# IMPORTANT:
# This does NOT change the figure's physical size.
# It only changes the internal position of the axes.
# ---------------------------------------------------------------------------

fig.tight_layout()


fig.subplots_adjust(
    top=0.94
)


# ---------------------------------------------------------------------------
# Save
#
# Keep the same output method as the previous script.
# ---------------------------------------------------------------------------

fig.savefig(

    "fig11.png",

    bbox_inches="tight",

    facecolor="white",
)


fig.savefig(

    "fig11.pdf",

    format="pdf",

    bbox_inches="tight",

    facecolor="white",
)


plt.close(
    fig
)


# ---------------------------------------------------------------------------
# Finished
# ---------------------------------------------------------------------------

print(
    "Figure 11 saved:"
)

print(
    "  fig11.png"
)

print(
    "  fig11.pdf"
)