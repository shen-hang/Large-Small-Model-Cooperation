"""Standalone script: reproduce Figure 3-11c — Experimental rounds vs Delay (ms).
Data extracted from task3.xlsx.
"""

import matplotlib.pyplot as plt

# ===========================================================================
# Data from task3.xlsx
# ===========================================================================
rounds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

vehicle   = [78.42, 79.84, 91.46, 76.95, 82.12, 83.80, 78.51, 84.55, 87.55, 83.32]
drone     = [92.15, 105.37, 96.16, 118.65, 98.73, 97.51, 95.17, 108.58, 115.05, 109.51]
satellite = [84.31, 98.09, 92.52, 82.01, 96.28, 89.20, 87.75, 111.11, 90.99, 97.36]

# ===========================================================================
# Global style
# ===========================================================================
plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 20,
    "axes.labelsize": 24,
    "axes.linewidth": 1.2,
    "axes.spines.top": True,
    "axes.spines.right": True,
    "axes.grid": True,
    "axes.axisbelow": True,
    "xtick.labelsize": 20,
    "ytick.labelsize": 20,
    "xtick.major.width": 1.2,
    "ytick.major.width": 1.2,
    "xtick.major.size": 7,
    "ytick.major.size": 7,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "grid.linewidth": 0.9,
    "grid.linestyle": "--",
    "grid.alpha": 0.4,
    "legend.fontsize": 30,
    "figure.dpi": 150,
    "savefig.dpi": 600,
})

# ===========================================================================
# Plot
# ===========================================================================
colors = {
    'vehicle':   '#2ca02c',
    'drone':     '#ff7f0e',
    'satellite': '#1f77b4',
}
markers = {
    'vehicle':   's',
    'drone':     'o',
    'satellite': '^',
}
linestyles = {
    'vehicle':   '-',
    'drone':     ':',
    'satellite': '--',
}

fig, ax = plt.subplots(figsize=(10, 7))

ax.plot(rounds, vehicle,   label='vehicle',   color=colors['vehicle'],   marker=markers['vehicle'],   linestyle=linestyles['vehicle'],   markerfacecolor='none', markersize=7, linewidth=2.0)
ax.plot(rounds, drone,     label='drone',     color=colors['drone'],     marker=markers['drone'],     linestyle=linestyles['drone'],     markerfacecolor='none', markersize=7, linewidth=2.0)
ax.plot(rounds, satellite, label='satellite', color=colors['satellite'], marker=markers['satellite'], linestyle=linestyles['satellite'], markerfacecolor='none', markersize=7, linewidth=2.0)

# --- Axes ---
ax.set_xlabel("Task rounds", fontsize=30)
ax.set_ylabel("Delay (ms)", fontsize=30)
ax.set_xlim(1, 10)
ax.set_ylim(60, 150)

# --- Legend & grid ---
ax.legend(fontsize=30, frameon=True)
ax.grid(True, linestyle='--', alpha=0.4)

# --- Save ---
fig.tight_layout()
fig.savefig("Fig3-11c.pdf", format='pdf', dpi=600, bbox_inches='tight', facecolor="white")
fig.savefig("Fig3-11c.png", dpi=600, bbox_inches='tight', facecolor="white")
print("Saved: Fig3-11c.pdf, Fig3-11c.png")
plt.close(fig)
