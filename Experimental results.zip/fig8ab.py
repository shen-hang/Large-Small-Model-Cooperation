"""Standalone script: reproduce Figure 3-8a & 3-8b — Average attack depth
and Average session duration across honeypot methods.

Reads existing session data from
``honeypot_exp/outputs/3-8(9)/session.csv``
and
``honeypot_exp/outputs/3-8(9)/baseline1_session.csv``.

Outputs:
    ``3-8a.png`` + ``3-8a.pdf``
    ``3-8b.png`` + ``3-8b.pdf``

Figure size:
    10 : 7

The PNG/PDF output uses ``bbox_inches="tight"`` consistently with
Figure 3-7.

Usage:
    conda activate day0812
    python plot_3_8ab.py
"""

from __future__ import annotations

import csv
from pathlib import Path
from statistics import mean, stdev

import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# Constants — keep identical to the original reporter.py
# ---------------------------------------------------------------------------

REPORT_METHODS = (
    "Baseline-2",
    "Baseline-3",
    "Proposed-2",
    "Proposed-5",
)

SESSION_MINUTES_PER_ROUND = 2.5


# ---------------------------------------------------------------------------
# Publication colors
#
# These colors and hatch patterns are kept consistent with the original
# Figure 3-8 style and the revised Figure 3-7 style.
# ---------------------------------------------------------------------------

ATTACK_DEPTH_COLORS = {
    "Baseline-1": "#7A8FA6",
    "Baseline-2": "#9BB7C9",
    "Baseline-3": "#89A99A",
    "Proposed-2": "#C58F7A",
    "Proposed-5": "#D2B86A",
}


ATTACK_DEPTH_PATTERNS = {
    "Baseline-1": "///",
    "Baseline-2": "...",
    "Baseline-3": "+++",
    "Proposed-2": "xxx",
    "Proposed-5": "\\\\",
}


ATTACK_DEPTH_EDGE_COLOR = "#444444"


# ---------------------------------------------------------------------------
# Data paths
# ---------------------------------------------------------------------------

DATA_DIR = Path("honeypot_exp/outputs/3-8(9)")

SESSION_CSV = DATA_DIR / "session.csv"

BASELINE1_CSV = DATA_DIR / "baseline1_session.csv"


# ---------------------------------------------------------------------------
# Data helpers
# ---------------------------------------------------------------------------

def load_sessions(csv_path: Path) -> list[dict[str, str]]:
    """Read session.csv and return rows sorted by method → task_id."""

    with csv_path.open(
        encoding="utf-8-sig",
        newline=""
    ) as handle:

        rows = list(csv.DictReader(handle))

    method_order = {
        m: i
        for i, m in enumerate(REPORT_METHODS)
    }

    rows.sort(
        key=lambda r: (
            method_order.get(r["method"], 99),
            r["task_id"]
        )
    )

    return rows


def load_baseline1(
    csv_path: Path
) -> list[dict[str, str]]:
    """Read baseline1_session.csv if it exists."""

    if not csv_path.exists():
        return []

    with csv_path.open(
        encoding="utf-8-sig",
        newline=""
    ) as handle:

        return list(csv.DictReader(handle))


# ---------------------------------------------------------------------------
# Plot configuration
# ---------------------------------------------------------------------------

def configure_plot() -> None:
    """Global matplotlib style matching the paper's publication format."""

    plt.rcParams.update({

        # ---------------------------------------------------------------
        # Font
        # ---------------------------------------------------------------
        "font.family": "Times New Roman",
        "font.size": 20,

        # ---------------------------------------------------------------
        # Axis
        # ---------------------------------------------------------------
        "axes.labelsize": 24,
        "axes.linewidth": 2.0,

        "axes.spines.top": True,
        "axes.spines.right": True,

        # ---------------------------------------------------------------
        # Grid
        # ---------------------------------------------------------------
        "axes.grid": True,
        "axes.axisbelow": True,

        # ---------------------------------------------------------------
        # Tick labels
        # ---------------------------------------------------------------
        "xtick.labelsize": 20,
        "ytick.labelsize": 20,

        "xtick.major.width": 2.0,
        "ytick.major.width": 2.0,

        "xtick.major.size": 7,
        "ytick.major.size": 7,

        "xtick.direction": "out",
        "ytick.direction": "out",

        # ---------------------------------------------------------------
        # Grid style
        # ---------------------------------------------------------------
        "grid.linewidth": 0.9,
        "grid.linestyle": "--",
        "grid.alpha": 0.3,

        # ---------------------------------------------------------------
        # Legend
        # ---------------------------------------------------------------
        "legend.fontsize": 20,

        # ---------------------------------------------------------------
        # Output resolution
        # ---------------------------------------------------------------
        "figure.dpi": 150,
        "savefig.dpi": 600,
    })


# ---------------------------------------------------------------------------
# Common formatting helper
# ---------------------------------------------------------------------------

def format_axes(ax) -> None:
    """Apply common axis/spine/tick formatting."""

    # -----------------------------------------------------------------------
    # Spines
    # -----------------------------------------------------------------------

    for spine in ax.spines.values():

        spine.set_color(
            ATTACK_DEPTH_EDGE_COLOR
        )

        spine.set_linewidth(2.0)

    # -----------------------------------------------------------------------
    # Tick parameters
    # -----------------------------------------------------------------------

    ax.tick_params(
        axis="both",
        which="both",
        direction="out",
        width=2.0,
        length=7,
        labelsize=22,
    )

    ax.tick_params(
        axis="y",
        which="major",
        width=2.2,
        length=10,
    )

    # -----------------------------------------------------------------------
    # Force Times New Roman
    # -----------------------------------------------------------------------

    for tick_label in (
        *ax.get_xticklabels(),
        *ax.get_yticklabels()
    ):

        tick_label.set_fontname(
            "Times New Roman"
        )

    # -----------------------------------------------------------------------
    # Grid
    # -----------------------------------------------------------------------

    ax.grid(
        True,
        axis="y",
        linestyle="--",
        alpha=0.3,
    )

    ax.grid(
        False,
        axis="x",
    )


# ---------------------------------------------------------------------------
# Figure 3-8a
# ---------------------------------------------------------------------------

def plot_figure_3_8a(
    rows: list[dict[str, str]],
    baseline1_rows: list[dict[str, str]],
    output_dir: Path,
) -> None:
    """Bar chart: average completed attack stages per method with 95% CI."""

    configure_plot()

    # -----------------------------------------------------------------------
    # Calculate data
    # -----------------------------------------------------------------------

    labels: list[str] = []

    means: list[float] = []

    ci95: list[float] = []

    # -----------------------------------------------------------------------
    # Baseline-1
    # -----------------------------------------------------------------------

    if baseline1_rows:

        depths = [
            float(row["attack_depth"])
            for row in baseline1_rows
        ]

        if len(depths) != 30:

            raise ValueError(
                "Baseline-1 replay must contain exactly 30 sessions"
            )

        labels.append("Baseline-1")

        means.append(
            mean(depths)
        )

        baseline1_std = stdev(depths)

        ci95.append(
            1.96
            * baseline1_std
            / (len(depths) ** 0.5)
        )

    # -----------------------------------------------------------------------
    # Other methods
    # -----------------------------------------------------------------------

    for method in REPORT_METHODS:

        group = [
            row
            for row in rows
            if row["method"] == method
        ]

        if not group:
            continue

        depths = [
            float(row["attack_depth"])
            for row in group
        ]

        labels.append(method)

        mu = mean(depths)

        means.append(mu)

        if len(depths) > 1:

            ci95.append(
                1.96
                * stdev(depths)
                / (len(depths) ** 0.5)
            )

        else:

            ci95.append(0.0)

    # -----------------------------------------------------------------------
    # Figure
    #
    # IMPORTANT:
    # Keep 10:7 aspect ratio.
    # -----------------------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(10, 7)
    )

    positions = list(
        range(len(labels))
    )

    # -----------------------------------------------------------------------
    # Bars
    # -----------------------------------------------------------------------

    bars = ax.bar(
        positions,
        means,

        width=0.36,

        color=[
            ATTACK_DEPTH_COLORS[label]
            for label in labels
        ],

        edgecolor=ATTACK_DEPTH_EDGE_COLOR,

        linewidth=1.2,

        yerr=ci95,

        capsize=5,

        error_kw={
            "ecolor": ATTACK_DEPTH_EDGE_COLOR,
            "elinewidth": 1.4,
            "capthick": 1.4,
        },
    )

    # -----------------------------------------------------------------------
    # Hatch patterns
    # -----------------------------------------------------------------------

    for bar, label in zip(
        bars,
        labels
    ):

        bar.set_hatch(
            ATTACK_DEPTH_PATTERNS[label]
        )

    # -----------------------------------------------------------------------
    # Value labels
    # -----------------------------------------------------------------------

    for position, value, error in zip(
        positions,
        means,
        ci95
    ):

        ax.text(
            position,

            value + error + 0.08,

            f"{value:.2f}",

            ha="center",
            va="bottom",

            fontsize=17,

            fontname="Times New Roman",
        )

    # -----------------------------------------------------------------------
    # Axes
    # -----------------------------------------------------------------------

    ax.set_xticks(
        positions,
        labels
    )

    ax.set_xlim(
        -0.5,
        len(labels) - 0.5
    )

    ax.set_ylim(
        0,
        4
    )

    ax.set_yticks(
        (0, 1, 2, 3, 4)
    )

    ax.set_ylabel(
        "Completed attack stages",
        fontsize=26,
        fontname="Times New Roman",
    )

    # -----------------------------------------------------------------------
    # Formatting
    # -----------------------------------------------------------------------

    format_axes(ax)

    # -----------------------------------------------------------------------
    # Layout
    #
    # Same principle as Figure 3-7:
    # use tight bounding-box cropping when saving.
    # -----------------------------------------------------------------------

    fig.tight_layout()

    # -----------------------------------------------------------------------
    # Save PNG + PDF
    # -----------------------------------------------------------------------

    png_path = output_dir / "3-8a.png"

    pdf_path = output_dir / "3-8a.pdf"

    fig.savefig(
        png_path,
        bbox_inches="tight",
        facecolor="white",
        dpi=600,
    )

    fig.savefig(
        pdf_path,
        format="pdf",
        bbox_inches="tight",
        facecolor="white",
    )

    plt.close(fig)

    print("Figure 3-8a saved:")

    print(
        f"  {png_path.resolve()}"
    )

    print(
        f"  {pdf_path.resolve()}"
    )


# ---------------------------------------------------------------------------
# Figure 3-8b
# ---------------------------------------------------------------------------

def plot_figure_3_8b(
    rows: list[dict[str, str]],
    baseline1_rows: list[dict[str, str]],
    output_dir: Path,
) -> None:
    """Bar chart: round-derived session duration per method with 95% CI."""

    configure_plot()

    # -----------------------------------------------------------------------
    # Calculate data
    # -----------------------------------------------------------------------

    labels: list[str] = []

    means: list[float] = []

    ci95: list[float] = []

    # -----------------------------------------------------------------------
    # Baseline-1
    # -----------------------------------------------------------------------

    if baseline1_rows:

        baseline1_rounds = [
            float(row["session_rounds"])
            for row in baseline1_rows
        ]

        if len(baseline1_rounds) != 30:

            raise ValueError(
                "Baseline-1 replay must contain exactly 30 sessions"
            )

        labels.append("Baseline-1")

        means.append(
            mean(baseline1_rounds)
            * SESSION_MINUTES_PER_ROUND
        )

        ci95.append(
            1.96
            * stdev(baseline1_rounds)
            / (len(baseline1_rounds) ** 0.5)
            * SESSION_MINUTES_PER_ROUND
        )

    # -----------------------------------------------------------------------
    # Other methods
    # -----------------------------------------------------------------------

    for method in REPORT_METHODS:

        group = [
            row
            for row in rows
            if row["method"] == method
        ]

        if not group:
            continue

        rounds = [
            float(row["session_rounds"])
            for row in group
        ]

        labels.append(method)

        mu = (
            mean(rounds)
            * SESSION_MINUTES_PER_ROUND
        )

        means.append(mu)

        if len(rounds) > 1:

            ci95.append(
                1.96
                * stdev(rounds)
                / (len(rounds) ** 0.5)
                * SESSION_MINUTES_PER_ROUND
            )

        else:

            ci95.append(0.0)

    # -----------------------------------------------------------------------
    # Figure
    #
    # IMPORTANT:
    # Keep exactly the same 10:7 aspect ratio as Figure 3-9a / 3-7.
    # -----------------------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(10, 7)
    )

    positions = list(
        range(len(labels))
    )

    # -----------------------------------------------------------------------
    # Bars
    # -----------------------------------------------------------------------

    bars = ax.bar(
        positions,
        means,

        width=0.36,

        color=[
            ATTACK_DEPTH_COLORS[label]
            for label in labels
        ],

        edgecolor=ATTACK_DEPTH_EDGE_COLOR,

        linewidth=1.2,

        yerr=ci95,

        capsize=5,

        error_kw={
            "ecolor": ATTACK_DEPTH_EDGE_COLOR,
            "elinewidth": 1.4,
            "capthick": 1.4,
        },
    )

    # -----------------------------------------------------------------------
    # Hatch patterns
    # -----------------------------------------------------------------------

    for bar, label in zip(
        bars,
        labels
    ):

        bar.set_hatch(
            ATTACK_DEPTH_PATTERNS[label]
        )

    # -----------------------------------------------------------------------
    # Value labels
    # -----------------------------------------------------------------------

    for position, value, error in zip(
        positions,
        means,
        ci95
    ):

        ax.text(
            position,

            value + error + 0.15,

            f"{value:.2f}",

            ha="center",
            va="bottom",

            fontsize=17,

            fontname="Times New Roman",
        )

    # -----------------------------------------------------------------------
    # Axes
    # -----------------------------------------------------------------------

    ax.set_xticks(
        positions,
        labels
    )

    ax.set_xlim(
        -0.5,
        len(labels) - 0.5
    )

    ax.set_ylim(
        0,
        12
    )

    ax.set_yticks(
        (0, 2, 4, 6, 8, 10, 12)
    )

    ax.set_ylabel(
        "Session duration (min)",
        fontsize=26,
        fontname="Times New Roman",
    )

    # -----------------------------------------------------------------------
    # Formatting
    # -----------------------------------------------------------------------

    format_axes(ax)

    # -----------------------------------------------------------------------
    # Layout
    # -----------------------------------------------------------------------

    fig.tight_layout()

    # -----------------------------------------------------------------------
    # Save PNG + PDF
    #
    # IMPORTANT:
    # bbox_inches="tight" makes the exported PDF cropped to the actual
    # figure contents, consistent with Figure 3-7.
    # -----------------------------------------------------------------------

    png_path = output_dir / "3-8b.png"

    pdf_path = output_dir / "3-8b.pdf"

    fig.savefig(
        png_path,
        bbox_inches="tight",
        facecolor="white",
        dpi=600,
    )

    fig.savefig(
        pdf_path,
        format="pdf",
        bbox_inches="tight",
        facecolor="white",
    )

    plt.close(fig)

    print("Figure 3-8b saved:")

    print(
        f"  {png_path.resolve()}"
    )

    print(
        f"  {pdf_path.resolve()}"
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:

    # -----------------------------------------------------------------------
    # Check session data
    # -----------------------------------------------------------------------

    if not SESSION_CSV.exists():

        raise SystemExit(
            f"Data file not found: {SESSION_CSV.resolve()}"
        )

    # -----------------------------------------------------------------------
    # Load data
    # -----------------------------------------------------------------------

    rows = load_sessions(
        SESSION_CSV
    )

    baseline1_rows = load_baseline1(
        BASELINE1_CSV
    )

    print(
        f"Loaded {len(rows)} session records "
        f"from {SESSION_CSV}"
    )

    if baseline1_rows:

        print(
            f"Loaded {len(baseline1_rows)} "
            f"Baseline-1 records "
            f"from {BASELINE1_CSV}"
        )

    else:

        print(
            f"Baseline-1 data not found at "
            f"{BASELINE1_CSV} — skipping Baseline-1 bar"
        )

    # -----------------------------------------------------------------------
    # Output directory
    # -----------------------------------------------------------------------

    output_dir = Path.cwd()

    # -----------------------------------------------------------------------
    # Generate Figure 3-8a
    # -----------------------------------------------------------------------

    plot_figure_3_8a(
        rows,
        baseline1_rows,
        output_dir
    )

    # -----------------------------------------------------------------------
    # Generate Figure 3-8b
    # -----------------------------------------------------------------------

    plot_figure_3_8b(
        rows,
        baseline1_rows,
        output_dir
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    main()