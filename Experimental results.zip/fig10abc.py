"""
Standalone script: reproduce Figure 3-10a, 3-10b & 3-10c — Reputation,
Group reward per round, and Cumulative group reward trajectories.

Reads pre-computed per-round data from `node_behavior_per_round.csv` and
outputs `3-10a.png` + `3-10a.pdf`, `3-10b.png` + `3-10b.pdf`,
`3-10c.png` + `3-10c.pdf` in the current directory.

Usage:
conda activate day0812
python plot_3_10.py
"""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

NODE_TYPES = (
    "High-value",
    "Novelty-oriented",
    "Effectiveness-oriented",
    "Medium-value",
    "Low-value",
    "Unreliable",
)

COLORS = [
    "#2ca02c",
    "#9467bd",
    "#1f77b4",
    "#ff7f0e",
    "#7f7f7f",
    "#8c564b",
]

MARKERS = ["D", "o", "^", "s", "v", "P"]

LINESTYLES = ["-", ":", "-.", "--", "-", "--"]


# ---------------------------------------------------------------------------
# Data path
# ---------------------------------------------------------------------------

CSV_PATH = Path("node_behavior_per_round.csv")


# ---------------------------------------------------------------------------
# Data loader
# ---------------------------------------------------------------------------

def load_per_round_data(csv_path: Path) -> dict[str, dict[str, list[float]]]:
    """
    Read node_behavior_per_round.csv.

    Returns:
        {
            column_name:
                {
                    node_type:
                        [values ordered by round]
                }
        }
    """

    with csv_path.open(
        encoding="utf-8-sig",
        newline=""
    ) as handle:
        rows = list(csv.DictReader(handle))


    numeric_cols = [
        "reputation_mean",
        "reward_per_round_mean",
        "cumulative_reward_mean",
    ]


    rounds = sorted(
        {int(row["round"]) for row in rows}
    )


    result = {}

    for col in numeric_cols:

        col_data = {
            nt: []
            for nt in NODE_TYPES
        }


        for r in rounds:

            for nt in NODE_TYPES:

                match = [
                    row
                    for row in rows
                    if int(row["round"]) == r
                    and row["node_type"] == nt
                ]


                if match and match[0].get(col):
                    value = float(match[0][col])
                else:
                    value = float("nan")


                col_data[nt].append(value)


        result[col] = col_data


    return result



# ---------------------------------------------------------------------------
# Plot configuration
# ---------------------------------------------------------------------------

def configure_plot():

    plt.rcParams.update({

        "font.family": "Times New Roman",

        "font.size": 20,

        "axes.labelsize": 24,

        "axes.linewidth": 1.4,

        "axes.spines.top": True,

        "axes.spines.right": True,

        "axes.grid": True,

        "axes.axisbelow": True,

        "xtick.labelsize": 18,

        "ytick.labelsize": 18,

        "xtick.major.width": 1.2,

        "ytick.major.width": 1.2,

        "xtick.major.size": 7,

        "ytick.major.size": 7,

        "xtick.direction": "out",

        "ytick.direction": "out",

        "grid.linewidth": 0.8,

        "grid.linestyle": "--",

        "grid.alpha": 0.4,

        "legend.fontsize": 22,

        "figure.dpi": 150,

        "savefig.dpi": 600,

    })



def save_figure(fig, output_dir: Path, stem: str):

    png_path = output_dir / f"{stem}.png"

    pdf_path = output_dir / f"{stem}.pdf"


    fig.tight_layout()


    fig.savefig(
        png_path,
        bbox_inches="tight",
        facecolor="white"
    )


    try:

        fig.savefig(
            pdf_path,
            format="pdf",
            bbox_inches="tight",
            facecolor="white"
        )

    except PermissionError:

        print(
            f"(Skipped {pdf_path.resolve()} — file locked)"
        )


    plt.close(fig)


    print(f"Figure {stem} saved:")
    print(f"  {png_path.resolve()}")

    if pdf_path.exists():
        print(f"  {pdf_path.resolve()}")



# ---------------------------------------------------------------------------
# Trajectory plot
# ---------------------------------------------------------------------------

def plot_trajectory(
    x,
    y_data,
    ylabel,
    stem,
    output_dir,
    ylim=None,
    xlabel="Round",
    legend_loc="upper left",
    legend_bbox=None,
):

    configure_plot()


    fig, ax = plt.subplots(
        figsize=(10, 7)
    )


    for group_id, node_type in enumerate(NODE_TYPES):

        y_values = y_data[node_type]

        mask = ~np.isnan(y_values)


        ax.plot(

            x[mask],

            np.array(y_values)[mask],

            label=node_type,

            color=COLORS[group_id],

            linestyle=LINESTYLES[group_id],

            marker=MARKERS[group_id],

            markerfacecolor="none",

            linewidth=2.0,

            markersize=6,

            markevery=10,

        )



    ax.set_xlabel(
        xlabel,
        fontsize=26
    )


    ax.set_ylabel(
        ylabel,
        fontsize=26
    )


    ax.tick_params(
        labelsize=18
    )


    ax.set_xlim(
        x[0],
        x[-1]
    )


    if ylim is not None:
        ax.set_ylim(*ylim)

    else:
        ax.set_ylim(bottom=0)



    ax.grid(
        True,
        linestyle="--",
        alpha=0.4
    )



    # ===============================
    # Legend position control
    # ===============================

    if legend_bbox is not None:

        ax.legend(
            fontsize=20,
            frameon=True,
            ncol=2,
            loc=legend_loc,
            bbox_to_anchor=legend_bbox,
        )

    else:

        ax.legend(
            fontsize=20,
            frameon=True,
            ncol=2,
            loc=legend_loc,
        )



    for tick_label in (
        *ax.get_xticklabels(),
        *ax.get_yticklabels()
    ):

        tick_label.set_fontname(
            "Times New Roman"
        )


    save_figure(
        fig,
        output_dir,
        stem
    )



# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():

    if not CSV_PATH.exists():

        raise SystemExit(
            f"Data file not found: {CSV_PATH.resolve()}"
        )


    data = load_per_round_data(
        CSV_PATH
    )


    rep_rounds = len(
        data["reputation_mean"][NODE_TYPES[0]]
    )


    reward_rounds = len(
        data["reward_per_round_mean"][NODE_TYPES[0]]
    )



    print(f"Loaded {CSV_PATH}")

    print(
        f"Reputation rounds: 0-{rep_rounds-1}"
    )

    print(
        f"Reward rounds: 1-{reward_rounds}"
    )



    output_dir = Path.cwd()



    # -------------------------------------------------
    # Figure 3-10a
    # -------------------------------------------------

    plot_trajectory(

        np.arange(rep_rounds),

        data["reputation_mean"],

        "Reputation",

        "3-10a",

        output_dir,

        ylim=(0.5, 1.2),

        xlabel="Task rounds",

    )



    # -------------------------------------------------
    # Figure 3-10b
    # Legend lowered here
    # -------------------------------------------------

    plot_trajectory(

        np.arange(1, reward_rounds + 1),

        data["reward_per_round_mean"],

        "Group reward per round",

        "3-10b",

        output_dir,

        xlabel="Task rounds",

        legend_loc="upper left",

        legend_bbox=(0, 0.80),

    )



    # -------------------------------------------------
    # Figure 3-10c
    # -------------------------------------------------

    plot_trajectory(

        np.arange(1, reward_rounds + 1),

        data["cumulative_reward_mean"],

        "Cumulative group reward",

        "3-10c",

        output_dir,

        xlabel="Task rounds",

    )



if __name__ == "__main__":

    main()