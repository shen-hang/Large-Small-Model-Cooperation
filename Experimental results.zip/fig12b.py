"""Standalone script: reproduce Figure 3-11b — Experimental rounds vs Delay (ms).
Data extracted from task1.xlsx.
"""

import matplotlib.pyplot as plt

# ===========================================================================
# Data from task1.xlsx
# ===========================================================================
rounds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

vehicle   = [288.37, 324.85, 295.42, 299.76, 306.21, 276.88, 304.73, 265.14, 273.36, 294.87]
drone     = [297.62, 355.47, 310.63, 308.14, 314.27, 286.39, 318.45, 271.58, 284.91, 300.23]
satellite = [304.11, 338.22, 289.71, 321.35, 309.54, 292.65, 314.16, 283.47, 296.22, 274.14]

# ===========================================================================
# Global style
# ===========================================================================
plt.rcParams.update({
    "font.family": "Times New Roman",
    "font.size": 20,
    "axes.labelsize": 24,
    "axes.linewidth": 1.2,
    "axes.spines.top": True,
    "axes.spines.right": True,
    "axes.grid": True,
    "axes.axisbelow": True,
    "xtick.labelsize": 20,
    "ytick.labelsize": 20,
    "xtick.major.width": 1.2,
    "ytick.major.width": 1.2,
    "xtick.major.size": 7,
    "ytick.major.size": 7,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "grid.linewidth": 0.9,
    "grid.linestyle": "--",
    "grid.alpha": 0.4,
    "legend.fontsize": 30,
    "figure.dpi": 150,
    "savefig.dpi": 600,
})

# ===========================================================================
# Plot
# ===========================================================================
colors = {
    'vehicle':   '#2ca02c',
    'drone':     '#ff7f0e',
    'satellite': '#1f77b4',
}
markers = {
    'vehicle':   's',
    'drone':     'o',
    'satellite': '^',
}
linestyles = {
    'vehicle':   '-',
    'drone':     ':',
    'satellite': '--',
}

fig, ax = plt.subplots(figsize=(10, 7))

ax.plot(rounds, vehicle,   label='vehicle',   color=colors['vehicle'],   marker=markers['vehicle'],   linestyle=linestyles['vehicle'],   markerfacecolor='none', markersize=7, linewidth=2.0)
ax.plot(rounds, drone,     label='drone',     color=colors['drone'],     marker=markers['drone'],     linestyle=linestyles['drone'],     markerfacecolor='none', markersize=7, linewidth=2.0)
ax.plot(rounds, satellite, label='satellite', color=colors['satellite'], marker=markers['satellite'], linestyle=linestyles['satellite'], markerfacecolor='none', markersize=7, linewidth=2.0)

# --- Axes ---
ax.set_xlabel("Task rounds", fontsize=30)
ax.set_ylabel("Delay (ms)", fontsize=30)
ax.set_xlim(1, 10)
ax.set_ylim(250, 380)

# --- Legend & grid ---
ax.legend(fontsize=30, frameon=True)
ax.grid(True, linestyle='--', alpha=0.4)

# --- Save ---
fig.tight_layout()
fig.savefig("Fig3-11b.pdf", format='pdf', dpi=600, bbox_inches='tight', facecolor="white")
fig.savefig("Fig3-11b.png", dpi=600, bbox_inches='tight', facecolor="white")
print("Saved: Fig3-11b.pdf, Fig3-11b.png")
plt.close(fig)
